PRAGMA foreign_keys = ON;

DROP TRIGGER IF EXISTS EnsureDoctorsSpecialization;
